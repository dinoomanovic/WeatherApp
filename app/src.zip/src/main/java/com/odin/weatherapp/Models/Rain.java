package com.odin.weatherapp.Models;

/**
 * Created by mobil on 04.02.2017.
 */

public class Rain {
    private int precipitation;

    public int getPrecipitation() {
        return precipitation;
    }

    public void setPrecipitation(int precipitation) {
        this.precipitation = precipitation;
    }
}
