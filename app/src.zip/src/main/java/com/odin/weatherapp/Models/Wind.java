package com.odin.weatherapp.Models;

/**
 * Created by mobil on 04.02.2017.
 */

public class Wind {
    private float deg;
    private float speed;

    public float getDeg() {
        return deg;
    }

    public void setDeg(float deg) {
        this.deg = deg;
    }

    public float getSpeed() {
        return speed;
    }

    public void setSpeed(float speed) {
        this.speed = speed;
    }
}
